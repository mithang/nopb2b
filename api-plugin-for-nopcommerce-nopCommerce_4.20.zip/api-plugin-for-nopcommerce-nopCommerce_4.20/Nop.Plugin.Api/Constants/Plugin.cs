﻿namespace Nop.Plugin.Api.Constants
{
    public class Plugin
    {
        public const string SystemName = "Nop.Plugin.Api";
    }
}