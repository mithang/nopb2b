﻿using Newtonsoft.Json;

namespace Nop.Plugin.Api.DTOs.ProductManufacturerMappings
{
    public class ProductManufacturerMappingsCountRootObject
    {
        [JsonProperty("count")]
        public int Count { get; set; }
    }
}