﻿namespace Nop.Plugin.Api.DTOs.Customers
{
    public class OrderCustomerDto : BaseCustomerDto
    {
         
    }
}