﻿using Nop.Services.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nop.Core.Plugins;
using System.Web.Routing;
using Nop.Services.Localization;
using Nop.Services.Configuration;

namespace Nop.Plugin.Misc.Logging.ElasticSearch
{
	public class ElasticSearchLoggerPlugin : BasePlugin , IMiscPlugin
	{

		private readonly ISettingService _settingService;

		public ElasticSearchLoggerPlugin(ISettingService settingService)
		{
			this._settingService = settingService;
		}

		public void GetConfigurationRoute(out string actionName, out string controllerName, out System.Web.Routing.RouteValueDictionary routeValues)
		{
			actionName = "Configure";
			controllerName = "ElasticSearch";
			routeValues = new RouteValueDictionary { { "Namespaces", "Nop.Plugin.Feed.Zbozi.Controllers" }, { "area", null } };

		}

		public void Install()
		{

			ElasticSearchLoggerSettings settings = new ElasticSearchLoggerSettings();
			settings.DefaultIndex = "NopCommerceLog";
			settings.ElasticSearchServer = "http://localhost:9200";
			_settingService.SaveSetting<ElasticSearchLoggerSettings>(settings);


			this.AddOrUpdatePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.Index", "Elastic search index");
			this.AddOrUpdatePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.ServerUrl", "Elastic search server");
			this.AddOrUpdatePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.Index.Hint", "An index is a collection of documents that have somewhat similar characteristics. For example, you can have an index for customer data, another index for a product catalog, and yet another index for order data. An index is identified by a name (that must be all lowercase) and this name is used to refer to the index when performing indexing, search, update, and delete operations against the documents in it. In a single cluster, you can define as many indexes as you want.");
			this.AddOrUpdatePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.ServerUrl.Hint", "Enter elastic search server url. Default url is http://localhost:9200");
			this.AddOrUpdatePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.General", "General");
			this.AddOrUpdatePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.GeneralInstructions", "<p><ul><li>Make sure that is your ElasticSearch server is running.</li><li><span style=\"color:red;\">After unistall plugin is necessary to remove plugin manually from plugin folder.</span></li><li>For more information about plugin you can visit <a target=\"_blank\" href=\"http://thsoftware.cz/elasticsearch-log-plugin-for-nopcommerce/\">my page</a> or find out more information about Elastic Search  <a target=\"_blank\" href=\"https://www.elastic.co/guide/en/elasticsearch/reference/current/_basic_concepts.html\">here</a> </li></ul></p>");

			base.Install();
		}

		public void Uninstall()
		{

			_settingService.DeleteSetting<ElasticSearchLoggerSettings>();
			
			this.DeletePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.Index");
			this.DeletePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.Index.Hint");
			this.DeletePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.ServerUrl");
			this.DeletePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.ServerUrl.Hint");
			this.DeletePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.General");
			this.DeletePluginLocaleResource("Nop.Plugin.Misc.Logging.ElasticSearch.GeneralInstructions");

			base.Uninstall();
		}
	}
}
