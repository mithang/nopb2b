﻿using Nop.Services.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Logging;
using Nop.Core.Data;
using Nop.Data;
using Nop.Core.Domain.Common;
using Nest;

namespace Nop.Plugin.Misc.Logging.ElasticSearch.Service
{
	public class ElasticSearchLogger : ILogger
	{

		#region Fields

		private readonly IWebHelper _webHelper;
		private readonly IDbContext _dbContext;
		private readonly IDataProvider _dataProvider;
		private readonly CommonSettings _commonSettings;
		private readonly ConnectionSettings connectionSettings;
		private readonly ElasticClient _elasticClient;
		private readonly ElasticSearchLoggerSettings _elasticSettigns;

		#endregion


		#region ctor 

		public ElasticSearchLogger(Core.Data.IRepository<Log> logRepository, IWebHelper webHelper, IDbContext dbContext, IDataProvider dataProvider, CommonSettings commonSettings, ElasticSearchLoggerSettings elasticSearchLoggerSettings)
		{
			_elasticSettigns = elasticSearchLoggerSettings;
			_webHelper = webHelper;
			_dbContext = dbContext;
			_dataProvider = dataProvider;
			_commonSettings = commonSettings;

			try
			{
				connectionSettings = new ConnectionSettings(new Uri(_elasticSettigns.ElasticSearchServer)).DefaultIndex(_elasticSettigns.DefaultIndex.ToLower());
				connectionSettings.DisableDirectStreaming();
				_elasticClient = new ElasticClient(connectionSettings);
			}
			catch (Exception ex)
			{

			}

		}


		#endregion


		#region Utitilities

		/// <summary>
		/// Gets a value indicating whether this message should not be logged
		/// </summary>
		/// <param name="message">Message</param>
		/// <returns>Result</returns>
		protected virtual bool IgnoreLog(string message)
		{
			if (!_commonSettings.IgnoreLogWordlist.Any())
				return false;

			if (String.IsNullOrWhiteSpace(message))
				return false;

			return _commonSettings
				.IgnoreLogWordlist
				.Any(x => message.IndexOf(x, StringComparison.InvariantCultureIgnoreCase) >= 0);
		}




		#endregion

		public void ClearLog()
		{
			var deleteResponse = _elasticClient.DeleteIndex("logs");

		}

		public void DeleteLog(Log log)
		{
			var response = _elasticClient.Delete<Log>(log.Id, d => d);
		}

		public void DeleteLogs(IList<Log> logs)
		{
			foreach (var log in logs)
			{
				DeleteLog(log);
			}
		}

		public IPagedList<Log> GetAllLogs(DateTime? fromUtc = null, DateTime? toUtc = null, string message = "", Core.Domain.Logging.LogLevel? logLevel = null, int pageIndex = 0, int pageSize = int.MaxValue)
		{

			int logLevelId = logLevel.HasValue ? (int)logLevel : 0;

			ISearchResponse<Log> searchResponse = null;

			if (logLevelId == 0)
			{
				searchResponse = _elasticClient.Search<Log>(s => s
						.Query(q => q
							.Bool(b => b
							 .Must(m => m
									.MultiMatch(ma => ma
											 .Fields(fs => fs
												 .Field(p => p.FullMessage)
												 .Field(p => p.ShortMessage)
											 )
											 .Operator(Operator.Or)
											 .Query(message)
										)
									)
						.Filter(bf => bf
							   .DateRange(r => r
								   .Field(f => f.CreatedOnUtc)
								   .GreaterThanOrEquals(fromUtc)
												  .LessThan(toUtc)
									 )
								)
								)
							)
						);
			}
			else
			{
				searchResponse = _elasticClient.Search<Log>(s => s
							.Query(q => q
								.Bool(b => b
								 .Must(m => m
										.MultiMatch(ma => ma
												 .Fields(fs => fs
													 .Field(p => p.FullMessage)
													 .Field(p => p.ShortMessage)
												 )
												 .Operator(Operator.Or)
												 .Query(message)
													),
											  ma => ma
										.Match(m => m
												.Field(f => f.LogLevelId)
												.Query(logLevelId.ToString())
											   )
										)
							.Filter(bf => bf
								   .DateRange(r => r
									   .Field(f => f.CreatedOnUtc)
									   .GreaterThanOrEquals(fromUtc)
													  .LessThan(toUtc)
										 )
									)
									)
								)
							);
			}



			return new PagedList<Log>(searchResponse.Documents.ToList(), pageIndex, pageSize);

		}

		public Log GetLogById(int logId)
		{

			var response = _elasticClient.Search<Log>(s => s
			.Query(q => q.Term(t => t.Field("_id").Value(logId)))); //Search based on _id    

			return response.Documents.FirstOrDefault();
		}

		public IList<Log> GetLogByIds(int[] logIds)
		{
			var logs = new List<Log>();

			foreach (int logId in logIds)
			{
				logs.Add(GetLogById(logId));
			}

			return logs;
		}

		public Log InsertLog(Core.Domain.Logging.LogLevel logLevel, string shortMessage, string fullMessage = "", Customer customer = null)
		{

			//check ignore word/phrase list?
			if (IgnoreLog(shortMessage) || IgnoreLog(fullMessage))
				return null;

			int logId = GetNextId();

			var log = new Log
			{
				Id = logId,
				LogLevel = logLevel,
				ShortMessage = shortMessage,
				FullMessage = fullMessage,
				IpAddress = _webHelper.GetCurrentIpAddress(),
				Customer = customer,
				CustomerId = customer != null ? customer.Id : 0,
				LogLevelId = (int)logLevel,
				PageUrl = _webHelper.GetThisPageUrl(true),
				ReferrerUrl = _webHelper.GetUrlReferrer(),
				CreatedOnUtc = DateTime.UtcNow
			};

			var response = _elasticClient.Index<Log>(log, i => i.Id(log.Id));



			return log;
		}

		private int GetNextId()
		{
			if (_elasticClient == null)
				return 0;


			var Match = _elasticClient.Search<Log>(_ => _
			.Take(1)
			.Sort(Q => Q.Descending(P => P.CreatedOnUtc)
			));

			if (Match != null)
			{
				var log = Match.Documents.FirstOrDefault();
				if (log != null)
				{
					return log.Id + 1;
				}
			}

			return 0;
		}


		public bool IsEnabled(Core.Domain.Logging.LogLevel level)
		{
			switch (level)
			{
				case Core.Domain.Logging.LogLevel.Debug:
					return false;
				default:
					return true;
			}
		}
	}
}
