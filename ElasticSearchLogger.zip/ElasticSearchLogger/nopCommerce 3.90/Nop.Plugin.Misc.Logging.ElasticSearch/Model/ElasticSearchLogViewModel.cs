﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Logging.ElasticSearch.Model
{
	public class ElasticSearchLogViewModel
	{
		[NopResourceDisplayName("Nop.Plugin.Misc.Logging.ElasticSearch.ServerUrl")]
		public string ElasticSearchServer { get; set; }

		[NopResourceDisplayName("Nop.Plugin.Misc.Logging.ElasticSearch.Index")]
		public string ElasticSearchIndex { get; set; }

	}
}
