﻿using Nop.Plugin.Misc.Logging.ElasticSearch.Model;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Web.Framework.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Nop.Plugin.Misc.Logging.ElasticSearch.Controllers
{
	public class ElasticSearchController : BasePluginController
	{

		private readonly ElasticSearchLoggerSettings _settings;
		private readonly ISettingService _settingService;
		private readonly ILocalizationService _localizationService;

		public ElasticSearchController(ElasticSearchLoggerSettings settings, ISettingService settingService, ILocalizationService localizationService)
		{
			_localizationService = localizationService;
			_settingService = settingService;
			_settings = settings;
		}

		public ActionResult Configure()
		{
			var viewModel = PrepareViewModel();
			return View("~/Plugins/Misc.Logging.ElasticSearch/Views/Configure.cshtml",viewModel);
		}


		[HttpPost]
		[ChildActionOnly]
		[FormValueRequired("save")]
		public ActionResult Configure(ElasticSearchLogViewModel model)
		{
			if (!ModelState.IsValid)
			{
				return Configure();
			}

			//save settings
			_settings.ElasticSearchServer = model.ElasticSearchServer;
			_settings.DefaultIndex = model.ElasticSearchIndex;
	
			_settingService.SaveSetting(_settings);

			SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));

			//redisplay the form
			return Configure();

		}

			private ElasticSearchLogViewModel PrepareViewModel()
		{
			return new ElasticSearchLogViewModel()
			{
				ElasticSearchIndex = _settings.DefaultIndex,
				ElasticSearchServer = _settings.ElasticSearchServer
			};
		}

	
	}
}
