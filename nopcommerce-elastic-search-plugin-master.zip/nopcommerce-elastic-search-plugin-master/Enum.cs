﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Search.Plugin.GSA
{
    public class Enum
    {
        public enum  DisplayType
        {
            Forecast = 1,
            Hotels = 2,
            BB = 3,
            Events = 4,
            Pictures = 5,
            Change = 6,
            General = 99
        } 
    }
}
