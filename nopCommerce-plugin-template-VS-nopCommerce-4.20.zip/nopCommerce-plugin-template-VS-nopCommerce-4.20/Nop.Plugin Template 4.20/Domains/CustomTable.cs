﻿using Nop.Core;

namespace $safeprojectname$.Domains
{
    public partial class CustomTable : BaseEntity
    {

    }
}
