﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Nop.Plugin.ExternalAuth.Database
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Plugin.ExternalAuth.Database.Login",
                 "Plugins/ExternalAuthDatabase/Login",
                 new { controller = "ExternalAuthDatabase", action = "Login" },
                 new[] { "Nop.Plugin.ExternalAuth.Database.Controllers" }
            );
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
