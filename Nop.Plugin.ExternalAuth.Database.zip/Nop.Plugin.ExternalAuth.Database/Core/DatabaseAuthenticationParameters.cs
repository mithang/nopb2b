﻿using Nop.Services.Authentication.External;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.ExternalAuth.Database.Core
{
    [Serializable]
    public sealed class DatabaseAuthenticationParameters : OpenAuthenticationParameters
    {
         public DatabaseAuthenticationParameters()
         {
             _claims = new List<UserClaims>();
             _claims.Add(new UserClaims());
             _claims[0].Name = new NameClaims();
             _claims[0].Person = new PersonClaims();
             _claims[0].Company = new CompanyClaims();
             _claims[0].Contact = new ContactClaims();             
         }

         public DatabaseAuthenticationParameters(string login, string email, string firstName, string lastName) : this()
         {
             this.ExternalDisplayIdentifier = login.ToLowerInvariant(); // We use the login as the external identifier for display
             this.ExternalIdentifier = GetMd5Hash(login.ToLowerInvariant()); // simple MD5 on login for the id
             
             this.UserClaims[0].Name.First = firstName;
             this.UserClaims[0].Name.Last = lastName;
             this.OAuthAccessToken = Guid.NewGuid().ToString();
             this.OAuthToken = Guid.NewGuid().ToString();
             this.UserClaims[0].Contact.Email = email.ToLowerInvariant();
         }

         private readonly IList<UserClaims> _claims;

         public override IList<UserClaims> UserClaims
         {
             get
             {
                 return _claims;
             }
         }

         public override string ProviderSystemName
         {
             get { return /* "ExternalAuth.Database" */Provider.SystemName; }
         }

        #region private methods
         static string GetMd5Hash(string input)
         {
             MD5 md5Hash = MD5.Create();
             // Convert the input string to a byte array and compute the hash.
             byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

             // Create a new Stringbuilder to collect the bytes
             // and create a string.
             StringBuilder sBuilder = new StringBuilder();

             // Loop through each byte of the hashed data 
             // and format each one as a hexadecimal string.
             for (int i = 0; i < data.Length; i++)
             {
                 sBuilder.Append(data[i].ToString("x2"));
             }

             // Return the hexadecimal string.
             return sBuilder.ToString();
         }
        #endregion
    }
}
