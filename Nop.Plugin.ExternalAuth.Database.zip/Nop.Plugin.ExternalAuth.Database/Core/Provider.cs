

namespace Nop.Plugin.ExternalAuth.Database.Core
{
    public static class Provider
    {
        public static string SystemName
        {
            get
            {
                return "ExternalAuth.Database";
            }
        }
    }
}