﻿using Nop.Services.Authentication.External;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Core.Domain.Customers;
using System.Security.Cryptography;
using Nop.Services.Security;
using Nop.Web.Framework.Controllers;
using Nop.Plugin.ExternalAuth.Database.Models;
using Nop.Services.Configuration;
using Nop.Services.Localization;

namespace Nop.Plugin.ExternalAuth.Database.Controllers
{
    public class ExternalAuthDatabaseController : Controller
    {
        private readonly IExternalAuthorizer _authorizer;
        private readonly ISettingService _settingService; 
        private readonly DatabaseExternalAuthSettings _databaseExternalAuthSettings;
        private readonly IPermissionService _permissionService;
        private readonly ILocalizationService _localizationService;
        

        public ExternalAuthDatabaseController(ISettingService settingService,
            DatabaseExternalAuthSettings databaseExternalAuthSettings,
            IPermissionService permissionService,
            ILocalizationService localizationService,
            IExternalAuthorizer authorizer)
        {
            this._settingService = settingService;
            this._databaseExternalAuthSettings = databaseExternalAuthSettings;
            _authorizer = authorizer;
            _permissionService = permissionService;
            _localizationService = localizationService;
        }


        [ChildActionOnly]
        public ActionResult PublicInfo()
        {
            return View("Nop.Plugin.ExternalAuth.Database.Views.ExternalAuthDatabase.PublicInfo");
        }
              

        [HttpPost]
        public ActionResult Login(Models.LoginModel model, string returnUrl)
        {
            AuthorizationResult result = CheckAndAuthorize(model);

            switch (result.Status)
            {
                case OpenAuthenticationStatus.Error:
                    {
                        if (!result.Success)
                            foreach (var error in result.Errors)
                                ExternalAuthorizerHelper.AddErrorsToDisplay(error);

                        return new RedirectResult(Url.LogOn(returnUrl));
                    }
                case OpenAuthenticationStatus.AssociateOnLogon:
                    {
                        return new RedirectResult(Url.LogOn(returnUrl));
                    }
                case OpenAuthenticationStatus.AutoRegisteredEmailValidation:
                    {
                        //result
                        return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.EmailValidation });
                    }
                case OpenAuthenticationStatus.AutoRegisteredAdminApproval:
                    {
                        return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.AdminApproval });
                    }
                case OpenAuthenticationStatus.AutoRegisteredStandard:
                    {
                        return RedirectToRoute("RegisterResult", new { resultId = (int)UserRegistrationType.Standard });
                    }

                case OpenAuthenticationStatus.Authenticated:
                    {
                        return new RedirectResult(!string.IsNullOrEmpty(returnUrl) ? returnUrl : "~/");
                    }

                default:
                    break;
            }

            return HttpContext.Request.IsAuthenticated ? new RedirectResult(!string.IsNullOrEmpty(returnUrl) ? returnUrl : "~/") : new RedirectResult(Url.LogOn(returnUrl));
        }

        private AuthorizationResult CheckAndAuthorize(Models.LoginModel model)
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_databaseExternalAuthSettings.ConnectionString))
            {
                connection.Open();
                using (System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(_databaseExternalAuthSettings.SQLQuery, connection))
                {
                    command.CommandType = System.Data.CommandType.Text;
                    command.Parameters.AddWithValue("login", model.Login);
                    command.Parameters.AddWithValue("password", model.Password);

                    using (System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string email = (string)reader["email"];
                            string firstName = (string)reader["firstName"];
                            string lastName = (string)reader["lastName"];

                            return _authorizer.Authorize(new Core.DatabaseAuthenticationParameters(model.Login, email, firstName, lastName));
                        }
                        else
                        {
                            AuthorizationResult failed = new AuthorizationResult(OpenAuthenticationStatus.Error);
                            failed.AddError(_localizationService.GetResource("Plugins.ExternalAuth.Database.LoginError")); // "Les informations ne correspondent pas à un utilisateur valide."); // TODO locale resources
                            return failed;
                        }                        
                    }
                }
            }                       
        }

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageExternalAuthenticationMethods))
                return Content("Access denied");

            var model = new ConfigurationModel();
            model.ConnectionString = _databaseExternalAuthSettings.ConnectionString;
            model.SQLQuery = _databaseExternalAuthSettings.SQLQuery;

            return View("Nop.Plugin.ExternalAuth.Database.Views.ExternalAuthDatabase.Configure", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageExternalAuthenticationMethods))
                return Content("Access denied");

            if (!ModelState.IsValid)
                return Configure();

            //save settings
            _databaseExternalAuthSettings.ConnectionString = model.ConnectionString;
            _databaseExternalAuthSettings.SQLQuery = model.SQLQuery;
            _settingService.SaveSetting(_databaseExternalAuthSettings);

            return View("Nop.Plugin.ExternalAuth.Database.Views.ExternalAuthDatabase.Configure", model);
        }                
    }
}
