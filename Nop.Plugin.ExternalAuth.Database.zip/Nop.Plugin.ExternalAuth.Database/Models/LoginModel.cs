﻿
namespace Nop.Plugin.ExternalAuth.Database.Models
{
    public class LoginModel
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}