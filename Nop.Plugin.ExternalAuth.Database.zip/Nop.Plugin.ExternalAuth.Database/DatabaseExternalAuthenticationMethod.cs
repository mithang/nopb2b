﻿using Nop.Core.Plugins;
using Nop.Services.Authentication.External;
using Nop.Services.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Routing;
using Nop.Services.Localization;

namespace Nop.Plugin.ExternalAuth.Database
{
    public class DatabaseExternalAuthenticationMethod : BasePlugin, IExternalAuthenticationMethod
    {
        #region Fields

        private readonly ISettingService _settingService;

        #endregion

        #region Ctor

        public DatabaseExternalAuthenticationMethod(ISettingService settingService)
        {
            this._settingService = settingService;
        }

        #endregion

        public void GetConfigurationRoute(out string actionName, out string controllerName, out System.Web.Routing.RouteValueDictionary routeValues)
        {
            // set like this if configuration is not required
            //actionName = null;
            //controllerName = null;
            //routeValues = null;

            actionName = "Configure";
            controllerName = "ExternalAuthDatabase";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Nop.Plugin.ExternalAuth.Database.Controllers" }, { "area", null } };
        }

        public void GetPublicInfoRoute(out string actionName, out string controllerName, out System.Web.Routing.RouteValueDictionary routeValues)
        {
            actionName = "PublicInfo";
            controllerName = "ExternalAuthDatabase";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Nop.Plugin.ExternalAuth.Database.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            var settings = new DatabaseExternalAuthSettings()
            {
                ConnectionString = "",
                SQLQuery = "",
            };
            _settingService.SaveSetting(settings);

            //locales
            this.AddOrUpdatePluginLocaleResource("Plugins.ExternalAuth.Database.LoginError", "User not found");
            this.AddOrUpdatePluginLocaleResource("Plugins.ExternalAuth.Database.Login", "Login using Database account");
            this.AddOrUpdatePluginLocaleResource("Plugins.ExternalAuth.Database.ConnectionString", "DB connection string");
            this.AddOrUpdatePluginLocaleResource("Plugins.ExternalAuth.Database.ConnectionString.Hint", "Entre your full sql server connection string.");
            this.AddOrUpdatePluginLocaleResource("Plugins.ExternalAuth.Database.SQLQuery", "Sql Query");
            this.AddOrUpdatePluginLocaleResource("Plugins.ExternalAuth.Database.SQLQuery.Hint", "The SQL query to get a user, this must return [Email], [FirstName] and [LastName] columns. Inputs parameters are @login and @password");
            
            base.Install();
        }

        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<DatabaseExternalAuthSettings>();

            //locales
            this.DeletePluginLocaleResource("Plugins.ExternalAuth.Database.LoginError");
            this.DeletePluginLocaleResource("Plugins.ExternalAuth.Database.Login");
            this.DeletePluginLocaleResource("Plugins.ExternalAuth.Database.ConnectionString");
            this.DeletePluginLocaleResource("Plugins.ExternalAuth.Database.ConnectionString.Hint");
            this.DeletePluginLocaleResource("Plugins.ExternalAuth.Database.SQLQuery");
            this.DeletePluginLocaleResource("Plugins.ExternalAuth.Database.SQLQuery.Hint");
            
            base.Uninstall();
        }
    }
}
